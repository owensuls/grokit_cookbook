# grokit

Cookbook for Grokit application.

Notes:
- In OpsWorks console:
  - After making change to recipe: 
    - berks package grokit.tar.gz
    - Upload to S3.
    - Update custom cookbooks.
    - Then Execute Recipe: grokit::grokit_install


Docker Setup notes:
- http://docs.aws.amazon.com/AmazonECS/latest/developerguide/docker-basics.html
- I had to allow Inbound traffic to port 80 for the "AWS OpsWorks Default server" security group, even though it says "do not change or delete".

sudo yum install -y docker
sudo service docker start
sudo usermod -a -G docker ec2-user
bash
docker info
sudo yum install -y git
git clone https://github.com/cpuguy83/docker-nagios
cd docker-nagios/
docker build -t my-dockerhub-username/docker-nagios .
docker images
docker run
