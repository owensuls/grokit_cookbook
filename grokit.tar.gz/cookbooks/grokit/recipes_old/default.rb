#
# Cookbook Name:: grokit
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
Chef::Log.info("********** Hello owen0937 **********")
