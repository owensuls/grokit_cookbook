user "Add a user" do
  home "/home/owens"
  shell "/bin/bash"
  username "owens"  
end
