service "Manage a service" do
  action :stop
  service_name "crond"  
end
